function showAlert() {
    alert(1);
}

function onloadAction() {
    //document.getElementById("menuHeader").innerText = "<i>Admin Dashboard</i>";
    document.querySelectorAll('[class="menu-header"]')[0].innerHTML = "<i>Admin Dashboard</i>";
    document.querySelectorAll('[class="menu-header"]')[1].innerHTML = "<i>Admin Dashboard</i>";
}