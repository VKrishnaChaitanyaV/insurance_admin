

function showHideAddNewPackage(){
    if(document.getElementById("addNewPackage").classList.contains("d-none")){
        document.getElementById("addNewPackage").classList.remove("d-none");
        document.getElementById("packageFrame").src = "../add-package/add-package.html";
    }
    else {
        document.getElementById("addNewPackage").classList.add("d-none");
    }
}

async function getPackagesData() {
    // try{
    //     .then(res=>res.json()).then(res=>{
    //         binddata(res);
    //     }).catch((ex)=>{
    //         alert("Exception from API");
    //     }).finally(()=>{
    //         alert("finally")
    //     });
    // }
    // catch(ex) {
    //     alert("Exception");
    // }
    try{
        let packages = [];
        packages = await fetch("http://localhost:3000/packages/")
        packages = packages.json();
        return packages;
    }
    catch(ex) {
        alert("Exception");
        return [];
    }
    
    
}

async function onLoad() {
    let packages = await getPackagesData();
    binddata(packages);
    //getPackagesData();
}

/*function binddata(packages) {
    if(Array.isArray(packages)) {
        for(let i=0; i<packages.length; i++) {
            document.getElementById("packageId"+i).innerHTML = packages[i].id;
            document.getElementById("title"+i).innerHTML = packages[i].title;
            document.getElementById("desc"+i).innerHTML = packages[i].desc;
            document.getElementById("amount"+i).innerHTML = packages[i].amount;
            document.getElementById("days"+i).innerHTML = packages[i].days;
        }
    }
}*/

function binddata(packages) {
    let tabledata = "";
    if(Array.isArray(packages)) {
        if(packages.length > 0) {
            for(let item of packages) {
                

                tabledata += `<tr>
                    <td>${ item.id }</td>
                    <td>${ item.title }</td>
                    <td>${ item.desc }</td>
                    <td>${ item.amount }</td>
                    <td>${ item.days }</td>
                    <td>
                        <label style="cursor: pointer;" onclick="editPackage(${ item.id })">&#X270E;</label>
                        <label style="cursor: pointer;">&#XE020;</label>
                    </td>
                </tr>`;
            }
        }
        else {
            tabledata += `<tr><td colspan="6">No Records Found.</td></tr>`;
        }
    }
    document.getElementById("tableData").innerHTML = tabledata;
}

function editPackage(id) {
   showHideAddNewPackage();
   document.getElementById("packageFrame").src = "../add-package/add-package.html?id="+id;
}

function closeAddPackagePopup() {
    showHideAddNewPackage();
    window.location.reload();
}