


function onLoad() {
    document.getElementById("canelPopupBtn").addEventListener("click", ()=>{

    });

    let searchparam = window.location.search;
    if(searchparam) {
        let id = searchparam.split("=")[1];
        fetch("http://localhost:3000/packages/"+id).then(res=>res.json()).then(res=>{
            document.getElementById("pId").value = res.id;
            document.getElementById("pTitle").value = res.title;
            document.getElementById("pAmount").value = res.amount;
            document.getElementById("pDays").value = res.days;
            document.getElementById("pDescription").value = res.desc;
            document.getElementById("btnSave").value = "Update";
        }).catch((ex)=>{
            alert("Exception");
        })
    }
    setDateTime();
    setInterval(setDateTime, 1000);
}

let setDateTime = ()=> {
    let currentDateTime = new Date();
    document.querySelector("#currentTime").innerHTML = currentDateTime;
}


async function addPackage() {
    let title = document.getElementById("pTitle").value;
    let amount = document.getElementById("pAmount").value;
    let days = document.getElementById("pDays").value;
    let desc = document.getElementById("pDescription").value;
    //Create object.
    let package = {
        "title" : title,
        "desc" : desc,
        "amount" : amount,
        "days" : days
    }

    if(document.querySelector("#pId").value > 0) {
        await updatePackage(package);
    }
    else {
        await saveNewPackage(package);
    }
    
}

async function saveNewPackage(package) {
    let options = {
        method: "POST",
        headers: {
            "content-type": "application/json"
        },
        body: JSON.stringify(package)
    }

    await fetch("http://localhost:3000/packages/", options);

    showSuccessMessage();
}

async function updatePackage(package) {
    package.id = document.getElementById("pId").value;
    let options = {
        method: "PUT",
        headers: {
            "content-type": "application/json"
        },
        body: JSON.stringify(package)
    }

    await fetch("http://localhost:3000/packages/"+package.id, options);

    showSuccessMessage();
}

function showSuccessMessage() {
      //Saved.
      document.querySelector("#successMessage").classList.remove("d-none");
    
      setTimeout(()=>{
          hideSuccessMessage()
      }, 3000);
}

function hideSuccessMessage() {
    document.querySelector("#successMessage").classList.add("d-none");
}

